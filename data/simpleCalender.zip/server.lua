
print("Hello world")