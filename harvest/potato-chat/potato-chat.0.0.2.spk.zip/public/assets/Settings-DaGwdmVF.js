import{j as t}from"./index-DtIX8s9P.js";const s=()=>t.jsx(t.Fragment,{});export{s as default};
